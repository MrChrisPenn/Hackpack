
from sense_emu import SenseHat
import mcpi.minecraft as minecraft
import mcpi.block as block
import time
import random
import sensehatemuGraph as sensehatgraph# reused code from Sensehat demo

"""
NCS team Pixel Astro Pi competition entry

We have created a bar graph in minecraft and store the values for temp and
humidity in two seperate lists.

We have reused The sensehat bar graph to add extra information.

Team members are:
Archie 
Tom 
Adrian 
"""

sense = SenseHat()

mc = minecraft.Minecraft.create()
orx,ory,orz = mc.player.getPos()

mc.postToChat("Start Graph")

TempBlock = 35,14

HumidityBlock = 35,3
Temperature_List = []#stores temp data
Humidity_List = []#stores humidity data 

DataStreamCount= 0

def BuildDataBlockTemp(ImportedBlock):# take data for temp
    temp = int(sense.temp)
    Temperature_List.append(temp)
    orx,ory,orz = mc.player.getPos()

    for i in range (0,temp):
        x,y,z = mc.player.getPos()
        mc.setBlock(x+30,i,z,ImportedBlock)
    mc.player.setPos(orx,ory,orz+1)
    msg = "Temp = {0}".format(temp)
    sense.show_message(msg, scroll_speed=0.10 )
    print(msg)
    time.sleep(4)
    sense.clear()

def BuildDataBlockHumidity(ImportedBlock):# take data for humidity 
    humidity = int(sense.humidity)
    Humidity_List.append(humidity)
    orx,ory,orz = mc.player.getPos()
    for i in range (0,humidity):
        x,y,z = mc.player.getPos()
        mc.setBlock(x+30,i,z,ImportedBlock)
    mc.player.setPos(orx,ory,orz+1)
    msg = "Humidity currently is: ",humidity 
    print(msg)
    msg = "humidity = {0}".format(humidity)
    sense.show_message(msg, scroll_speed=0.10 )
    time.sleep(4)
    sense.clear()
    
while True:
    BuildDataBlockTemp(TempBlock) # 46
    BuildDataBlockHumidity(HumidityBlock)
    sensehatgraph.main()
    sense.clear()
