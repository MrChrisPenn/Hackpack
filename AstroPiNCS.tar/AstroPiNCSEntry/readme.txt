To get this to work. We used the sense hat emulator it is still coded to work with the emulator. 

1. open the code.py file
2. open the sensehat emulator (pi version not web based)
3. open minecraft create a new world
4. run code.py file