"""
0. Place the folder with this hack in on the desktop
1. Build something in minecraft on Raspberry Pi.
2. Install twython by typing sudo pip3 install twython in lx terminal
4. Create a twitter app I used Raspberry Pi foundation
tweeting babbage tutorial.
5. Run this python script in python 3.4
6. Position yourself in minecraft
7. Right click and go to twitter :) and see your build
"""
__author__ = '@ncscomputing'
from mcpi import minecraft as minecraft
from mcpi import block as block

import time

import random
import subprocess

#====twitter info
import sys
from twython import Twython

#once you have created your own Twitter app put in your info below

consumer_key = ''
consumer_secret = ''
access_token = ''
access_token_secret = ''

api = Twython(consumer_key,consumer_secret,access_token,access_token_secret)

#===
mc = minecraft.Minecraft.create()
while True:

    evs = mc.events.pollBlockHits()
    for e in evs:
        pos = e.pos


        block = mc.getBlock(pos.x,pos.y,pos.z)
        mc.postToChat("@warksraspijam built this :)")
        msg = "#iob Tweeting what I built :)"
        a=subprocess.check_output('./raspi2png -d 3 -p "myscreenshot.png"',shell=True)
        photo = open('/home/pi/Desktop/LookWhatIBuiltV1/myscreenshot.png', 'rb')
        response = api.upload_media(media=photo)
        api.update_status(status = msg, media_ids=[response['media_id']])
        
