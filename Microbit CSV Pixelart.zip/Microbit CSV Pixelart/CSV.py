import csv

f = open('test2.csv', 'rt')
try:
    reader = csv.reader(f)
    for row in reader:
        print row
finally:
    f.close()
