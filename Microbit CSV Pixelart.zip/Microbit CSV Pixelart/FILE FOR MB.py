from microbit import*
import random

REFRESH = 500

#blocksList = [2,1,3,9,7,8]

def get_data():
    #x, y, z = accelerometer.get_x(), accelerometer.get_y(), accelerometer.get_z()
    a, b = button_a.was_pressed(), button_b.was_pressed()
    #block = random.choice(blocksList)
    #msg = str(block)
    #display.show(msg)
    print(a, b)

def run():
    while True:
        sleep(REFRESH)
        get_data()

display.show('W')
#microbit.display.scroll("wrj")
run()
