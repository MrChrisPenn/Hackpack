import serial
from mcpi.minecraft import Minecraft
import mcpi.block as block
from time import sleep
import mcpiselfie as selfie
#=====
import picamera
from PIL import Image
import math
from mcpi.minecraft import Minecraft
from time import sleep, time
__author__ = '@ncscomputing'
from mcpi import minecraft as minecraft
from mcpi import block as block

import random
import subprocess
import picamera
from PIL import Image
import PixelatedStarTrooper as PixelatedStarTrooper
#====twitter info


def takePicture(filename):
    with picamera.PiCamera() as camera:
        camera.start_preview(alpha=192)
        sleep(1)
        camera.capture(filename)
        camera.stop_preview()

#=====



PORT = "/dev/ttyACM0"
BAUD = 115200

s = serial.Serial(PORT)
s.baudrate = BAUD
s.parity   = serial.PARITY_NONE
s.databits = serial.EIGHTBITS
s.stopbits = serial.STOPBITS_ONE
#read the first line and flush any bad data
s.readline()


def read_microbit_data():
    #read a line from the microbit, 
    data = s.readline()
    #split the microbit data into x, y, z, a, b
    data_s = data.rstrip().split(" ")
    #x, y, z = int(data_s[0]), int(data_s[1]), int(data_s[2])
    a = True if data_s[0] == "True" else False
    b = True if data_s[1] == "True" else False
    #block = int(data_s[5])
   
    return a,b#x, y, z, a, b,block

mc = Minecraft.create()

try:
    playerPos = mc.player.getTilePos()
    
    
    
    while True:
        a,b= read_microbit_data()
        #   print a
        if a == True:
            
            msg = "Button pressed = ",str(a)
            mc.postToChat(msg)
            selfie.main(playerPos)
            #takePicture('/home/pi/Desktop/microbit-micropython-master/microbit-micropython-master/examples/mcfly/Geoff.jpg')

        if b == True:
            msg = "Pixelated stormy"
            mc.postToChat(msg)
            PixelatedStarTrooper.main()
        #print msg
        #pos = mc.player.getPos()
        #mc.setBlock(pos.x,pos.y-1,pos.z,block)
            
            
        
    
finally:
    sleep(1)
    s.close()
