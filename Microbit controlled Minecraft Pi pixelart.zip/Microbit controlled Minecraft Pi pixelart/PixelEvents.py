import serial
from mcpi.minecraft import Minecraft
from time import sleep
#from mcpi.minecraft import Minecraft
from time import sleep, time
from mcpi import block as block
import random
import pixelart as pa

PORT = "/dev/ttyACM0"
BAUD = 115200

s = serial.Serial(PORT)
s.baudrate = BAUD
s.parity   = serial.PARITY_NONE
s.databits = serial.EIGHTBITS
s.stopbits = serial.STOPBITS_ONE
#read the first line and flush any bad data
s.readline()


def read_microbit_data():
    #read a line from the microbit, 
    data = s.readline()
    #split the microbit data into x, y, z, a, b
    data_s = data.rstrip().split(" ")
    a = True if data_s[0] == "True" else False
    b = True if data_s[1] == "True" else False
    return a,b

mc = Minecraft.create()

try:
    playerPos = mc.player.getTilePos()
    
    
    
    while True:
        a,b= read_microbit_data()
        if a == True:
            msg = "Button pressed = ",str(a)
            mc.postToChat(msg)
            #PUT YOUR INSTRUCTIONS HERE
            pa.printCustom()
            
        if b == True:
            msg = "Button pressed = ",str(b)
            mc.postToChat(msg)
            #PUT YOUR INSTRUCTIONS HERE
            pa.main()
         
        
finally:
    sleep(1)
    s.close()
