"""
Code written by Martin O'Hanlon in the following blog post:
http://www.stuffaboutcode.com/2016/03/microbit-get-data-from-usb.html
"""
import PixelatedStarTrooper as pst
import time 
import serial
from mcpi.minecraft import Minecraft
from time import sleep
from mcpi import block as block
import random

PORT = "/dev/ttyACM0"
BAUD = 115200

s = serial.Serial(PORT)
s.baudrate = BAUD
s.parity   = serial.PARITY_NONE
s.databits = serial.EIGHTBITS
s.stopbits = serial.STOPBITS_ONE
#read the first line and flush any bad data
s.readline()

def read_microbit_data():
    #read a line from the microbit, 
    data = s.readline()
    data_s = data.rstrip().split(" ")
    mbReading = data_s[0]
    print mbReading
    return mbReading

mc = Minecraft.create()
try:
    playerPos = mc.player.getTilePos()
    while True:
        mbReading = read_microbit_data()
        if mbReading == "Stormy":
            #pos = mc.player.getPos()
            msg = mbReading
            mc.postToChat(msg)
            pst.StMain()#Stormy built
            
               
finally:
    sleep(1)
    s.close()

