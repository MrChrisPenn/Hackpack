Instructions:

Most of the tricky MB code and MB reader was written by David Whale and edited by Martin O'Hanlon. 

I have built in stuff on top of that:

1. use the alpha version of microbit.org python editor to load the RadioStormyMB.py code onto two microbits 
2. Load the PixelatedStarTrooper.py and the RadioStormy.py onto a Raspberry Pi. 
3. Open Python 2.7
4. Load the RadioStormy.py 
5. Open Minecaft, load a new world
6. Run RadioStormy.py
7. Attach one Microbit to the Pi
8. Run one microbit and press the A button
9. Sit back relax and enjoy the force!

Over! :)
