#Written by @ncscomputing / @warksraspijam

#import led controlling libraries # written by pocket moneytronics
import example_1 as e1
import example_2 as e2
import example_3 as e3
import example_4 as e4
import example_5 as e5
import example_6 as e6

#import minecraft libraries
import mcpi.minecraft as minecraft
import mcpi.block as block

mc = minecraft.Minecraft.create()

mc.postToChat("Welcome to Steves Warwickshire Raspberry Jam Christmas light turn on 2015 uisng pocket money tronics christmas tree / and their 6 demo  programs :)")

while True:

    evs = mc.events.pollBlockHits()
    for e in evs:
        pos = e.pos

        b = mc.getBlock(pos.x,pos.y,pos.z)
        if b == 46:#tnt
            mc.postToChat("You chose Pocket Money tronics demo 1")
            e1.oneMain()
        elif b == 20:#glass
            mc.postToChat("You chose Pocket Money tronics demo 2")
            e2.twoMain()
        elif b == 41:#gold  
            mc.postToChat("You chose Pocket Money tronics demo 3")
            e3.threeMain()
        elif b == 2:#grass
            mc.postToChat("You chose Pocket Money tronics demo 4")
            e4.fourMain()
        elif b == 26:#bed
            mc.postToChat("You chose Pocket Money tronics demo 5")
            e5.fiveMain()
        elif b == 45:#brick
            mc.postToChat("You chose Pocket Money tronics demo 6")
            e6.sixMain()
