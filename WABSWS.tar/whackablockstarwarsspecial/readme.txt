this code is based on the mcpistuff library created by Martion O'Hanlon 
you can access his content from http://www.stuffaboutcode.com/

the moving X-Wing was also created by MOH. Some further work was then done by Dr Scott Turner
you can find out more about his stuff from here: https://computingnorthampton.blogspot.co.uk/

I have built the pixelart. 

This works in ahem python 2.7. sorry 3.5 avocates. I'm sure it can be converted but I don't have
the time.