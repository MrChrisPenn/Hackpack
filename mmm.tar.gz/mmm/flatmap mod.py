import sys
import mcpi.minecraft as minecraft
import mcpi.block as block

# created by http://www.minecraftforum.net/forums/other-platforms/minecraft-pi-edition/1959866-simple-flatmap-script

mc = minecraft.Minecraft.create()
#mc.setBlocks(-128,0,-128,128,64,128,0)


mc.setBlocks(-128,0,-128,128,-64,128,20)

