#written by Martin O'Hanlon
#Original version available here:https://github.com/martinohanlon/minecraft-turtle
#As ever tweaked a tiny bit by me @warksraspijam

#Minecraft Turtle Example
import minecraftturtle
import mcpi.minecraft as minecraft
import mcpi.block as block
import time
#Minecraft Turtle Example - Spiral
import random

#create connection to minecraft
mc = minecraft.Minecraft.create()

#get players position
pos = mc.player.getPos()

WoolIds = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]

def Function(steve):
    #create minecraft turtle
    

    steve.penblock(block.WOOL.id,random.choice(WoolIds))
    steve.speed(10)
    steve.up(0.25)

    for step in range(0,25):
        steve.forward(2)
        steve.right(10)
    mc.postToChat("done")

steve = minecraftturtle.MinecraftTurtle(mc, pos)
Function(steve)
mc.camera.setFollow()
    #mc.player.setting("autojump", False)
pos = mc.player.getPos()
mc.player.setPos(pos.x,pos.y+40,pos.z)

while True:
    pos = mc.player.getPos()
    mc.player.setPos(pos.x,pos.y+40,pos.z)
    Function(steve)
    time.sleep(1)
    mc.postToChat("again")
